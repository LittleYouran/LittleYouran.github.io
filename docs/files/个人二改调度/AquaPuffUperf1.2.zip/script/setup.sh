#!/system/bin/sh

#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

BASEDIR="$(dirname $(readlink -f "$0"))"
. $BASEDIR/pathinfo.sh
. $BASEDIR/libsysinfo.sh

########################################
# $1:error_message
abort() {
    echo "[ERROR] $1"
    echo "Uperf installation failed."
    exit 1
}

set_perm() {
    chown $2:$3 $1
    chmod $4 $1
    chcon $5 $1
}

set_perm_recursive() {
    find $1 -type d 2>/dev/null | while read dir; do
        set_perm $dir $2 $3 $4 $6
    done
    find $1 -type f -o -type l 2>/dev/null | while read file; do
        set_perm $file $2 $3 $5 $6
    done
}

get_socid() {
    cat /sys/devices/soc0/soc_id 2>/dev/null || 
    cat /sys/devices/system/soc/soc0/id 2>/dev/null
}

get_socname() {
    tr '[:upper:]' '[:lower:]' < /sys/devices/soc0/machine
}

get_nr_core() {
    grep -c '^cpu[0-9]' /proc/stat
}

is_aarch64() {
    [ "$(getprop ro.product.cpu.abi)" = "arm64-v8a" ]
}

is_eas() {
    grep -q 'sched' /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors
}

install_uperf() {
      echo "- ฅ^•ﻌ•^ฅ 正在嗅探设备信息..."
      echo " 设备信息检测"
      echo " ro.board.platform= $(getprop ro.board.platform)"
      echo " ro.product.board= $(getprop ro.product.board)"

      local target cfgname
      target="$(getprop ro.board.platform)"
      cfgname="$(get_config_name $target)"
      config=${cfgname:0:2}
      
    
      if [ "$cfgname" == "unsupported" ]; then
      target="$(getprop ro.product.board)"
      cfgname="$(get_config_name $target)"
      config=${cfgname:0:2}
      fi
      echo $config
      echo "- (=^･ω･^=) 找到匹配的配置啦：$cfgname"
      echo "----------------------------------------"
    sleep 0.2
    echo "请选择配置文件目录：
👆🏻按音量上键安装 'config' 配置文件（可能更卡）👆🏻
👇🏻按音量下键浏览更多配置选项👇🏻
  注意 现版本（1.1）省电选择config  游戏选择config2
  但是config2也不推荐 请直接按音量上键安装config
  config3 完全不可选
  选择其他配置文件不给予处理"
       config_choice=""
       while [ -z "$config_choice" ]; do
       config_choice=$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')
       sleep 0.2
       done
       case "$config_choice" in
       "KEY_VOLUMEUP")      
       cfgfolder="$MODULE_PATH/config"
       a=1
       ;;
       "KEY_VOLUMEDOWN")
    echo "请选择配置类型：
👆🏻按音量上键安装 'config2👆🏻'
👇🏻按音量下键安装 'config3👇🏻"
       config_subchoice=""
       while [ -z "$config_subchoice" ]; do
       config_subchoice=$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')
       sleep 0.2
       done
       case "$config_subchoice" in
      "KEY_VOLUMEUP")
       cfgfolder="$MODULE_PATH/config/config2"
       ;;
      "KEY_VOLUMEDOWN")
       cfgfolder="$MODULE_PATH/config/config3"
       ;;
       *)
       cfgfolder="$MODULE_PATH/config/config2"
       ;;
       esac
       ;;
       *)
       cfgfolder="$MODULE_PATH/config"
           ;;
       esac

    selected_cfg="$cfgname.json"

    if [ ! -f "$cfgfolder/$selected_cfg" ]; then
        echo ""
        abort "! 你选择的目录里没有相应的配置文件喵～"
    fi

        mkdir -p $USER_PATH
        mv -f $USER_PATH/uperf.json $USER_PATH/uperf.json.bak 2>/dev/null
        cp -f "$cfgfolder/$selected_cfg" $USER_PATH/uperf.json

        
        [ ! -e "$USER_PATH/perapp_powermode.txt" ] && cp $MODULE_PATH/config/perapp_powermode.txt $USER_PATH/perapp_powermode.txt

        set_perm_recursive $BIN_PATH 0 0 0755 0755 u:object_r:system_file:s0
}

vulkan_installer() {
    echo "----------------------------------------"
    echo "👆🏻 点按音量上键安装Vulkan渲染 👆🏻"
    sleep 0.5
    echo "👇🏻 点按音量下键取消安装 👇🏻"
    echo "注：优化作用有限，可加可不加
可能会卡开机
几率很小 卡开机不接受反馈
本人用着没事"
    
    local choice=""
    while [[ -z "$choice" ]]; do
        choice=$(getevent -qlc 1 | awk '{ print $3 }' | grep 'KEY_')
        sleep 0.2
    done

    case "$choice" in
        "KEY_VOLUMEUP")
            echo "正在安装Vulkan渲染..."
            if [[ "$config" = "sd" ]]; then
                sh "${MODULE_PATH}/script/xiaolovk.sh"
            elif [[ "$config" = "mt" ]]; then
                sh "${MODULE_PATH}/script/tianjivk.sh"
            fi
            ;;
        "KEY_VOLUMEDOWN")
            echo "已取消安装Vulkan渲染"
            ;;
        *)
            echo "无效选择，已跳过Vulkan渲染安装"
            ;;
    esac
}

echo "----------------------------------------"
echo " QuanGui Uperf "
echo "----------------------------------------"
echo " 改 小疣然"
echo " Uperf原项目网址:https://github.com/yc9559/uperf/ "
echo "----------------------------------------"
echo "👁️👁️请认真看重要提示 里面有你想知道的一切👁️👁️"
echo "你不看 问我问题 我装瞎"
echo "----------------------------------------"

        echo "开始安装..."

        install_uperf
        vulkan_installer
        
        
        echo "----------------------------------------"
        echo " 安装成功!"
        echo " 呜嘿嘿  感谢@RalseiNEO 大姐姐完成的 vk 选择"
        sleep 1
        echo "----------------------------------------"
        echo" "
        echo " 重要提示:"
        echo " 1. 重启设备使配置生效"
        echo " 2. WALT参数备份位置: /sdcard/Android/uperf_backup"
        echo " 3. 日志路径: /sdcard/Android/yc/uperf/uperf_log.txt"
        echo " 4. 配置文件路径: /sdcard/Android/yc/uperf/uperf.json"
        echo " 5. 修改配置后可能需要执行:"
        echo "                 /data/adb/modules/uperf/service.sh"
        echo " 6. 遇到错误 请截图发到群里 或者小绿书评论区"
        echo " 7. 群聊 1029460997 / 542350151 / 817180647"
        echo " "
        echo "雪莉酱卡哇伊daisuki！！！
        
        小疣然: Merry Christmas （圣诞快乐）
                    🌟
                   🎄🎄
                  🎄🎄🎄
                 🎄🎄🎄🎄
                🎄🎄🎄🎄🎄
               🎄🎄🎄🎄🎄🎄
                 [🎁][🎁]
                   [🦌]
    如果你见到了圣诞老人跟他说别送他都没有的"
        echo "----------------------------------------
     KEY_VOLUMEDOWN"

exit 0