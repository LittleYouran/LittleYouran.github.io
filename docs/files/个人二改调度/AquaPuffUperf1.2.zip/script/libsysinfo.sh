#!/system/bin/sh
#
# Copyright (C) 2021-2022 Matt Yang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

###############################
# Platform info functions
###############################

match_linux_version() {
    echo "$(cat /proc/version | grep -i "$1")"
}

get_socid() {
    if [ -f /sys/devices/soc0/soc_id ]; then
        echo "$(cat /sys/devices/soc0/soc_id)"
    else
        echo "$(cat /sys/devices/system/soc/soc0/id)"
    fi
}

get_socname() {
    echo "$(cat "/sys/devices/soc0/machine"| tr '[A-Z]' '[a-z]')"
}

get_nr_core() {
    echo "$(cat /proc/stat | grep cpu[0-9] | wc -l)"
}

get_maxfreq() {
    echo "$(cat "/sys/devices/system/cpu/cpu$1/cpufreq/cpuinfo_max_freq")"
}

get_2maxfreq() {
    echo "$(cat "/sys/devices/system/cpu/cpu$1/cpufreq/cpuinfo_max_freq" 2>/dev/null | head -c 2)"
}

is_aarch64() {
    if [ "$(getprop ro.product.cpu.abi)" == "arm64-v8a" ]; then
        echo "true"
    else
        echo "false"
    fi
}

is_eas() {
    if [ "$(grep sched /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors)" != "" ]; then
        echo "true"
    else
        echo "false"
    fi
}

is_mtk() {
    if [ "$(getprop | grep ro.mtk)" != "" ]; then
        echo "true"
    else
        echo "false"
    fi
}

_get_kona_type() {
    if [ "$(get_maxfreq 7)" -gt 3100000 ]; then
        echo "sdm870"
    else
        echo "sdm865"
    fi
}

_get_taro_type() {
    if [ "$(get_maxfreq 7)" -le 2918400 ]; then
        echo "sdm7g2+"
        return
    fi
    if [ "$(get_socname)" == cape ] || [ "$(get_socname)" == capep ] || [ "$(get_socname)" == ukee ] || [ "$(get_socname)" == ukeep ]; then
        echo "sdm8g1+"
    else
        if [ "$(get_socname)" == waipio ] || [ "$(get_socname)" == waipiop ]; then
            echo "sdm8g1"
        fi
    fi
}

# 8g4/8sg4检测函数
get_sun_machine_name() {
    if [ "$(get_2maxfreq 7)" -gt 43 ]; then
        echo "sdm8g4"
    else
        if [ "$(get_2maxfreq 7)" -gt 32 ]; then
            echo "sdm8sg4"
        fi
    fi
}

get_config_socmodel_name() {
    case "$1" in
    "MT6895") echo "mtd8000" ;;
    "MT6895") echo "mtd8100" ;;
    "MT6896" | "MT6896Z" | "MT6896Z/CZA") echo "mtd8200" ;;
    "MT6897") echo "mtd8300Ultra" ;;
    *) echo "unsupported" ;;
    esac
}

get_config_name() {
    case "$1" in  
    "holi") echo "sdm4gen1" ;; 
    "SM8650") echo "sdm8elite" ;;
    "SUN") echo "sdm8elite" ;; 
    "sun") echo "sdm8elite" ;; 
    "pineapple") echo "sdm8g3" ;;
    "kalama") echo "sdm8g2" ;;
    "sm8475") echo "$(_get_taro_type)" ;; 
    "taro") echo "$(_get_taro_type)" ;;
    "sm7475") echo "sdm7g2+" ;;
    "garnet") echo "sdm7sgen2" ;;
    "lahaina") echo "sdm888" ;;
    "am8350") echo "sdm888" ;;
    "msmnile") echo "sdm855" ;;
    "sdm845") echo "sdm845" ;;
    "shima") echo "sdm888" ;;
    "yupik") echo "sdm888" ;;
    "kona") echo "$(_get_kona_type)" ;;
    "mt6789") echo "mtg99" ;;
    "mt6785") echo "mtg90t" ;;
    "mt6789"*) echo "mtg99" ;;
    "mt6833") echo "mtd720" ;;
    "mt6833p") echo "mtd720" ;;
    "mt6833v") echo "mtd720" ;;
    "mt6853") echo "mtd720" ;;
    "knoa") echo "mtd870" ;;
    "mt6873") echo "mtd820" ;;
    "mt6875") echo "mtd820" ;;
    "mt6877") echo "mtd920" ;;
    "mt6885") echo "mtd1000" ;;
    "mt6891") echo "mtd1100" ;; 
    "mt6893") echo "mtd1200" ;;
    "mt6895") echo "mtd8100" ;;
    "mt6896") echo "mtd8200" ;;
    "mt6897") echo "mtd8300Ultra" ;;
    "mt6983") echo "mtd9000" ;;
    "mt6985") echo "mtd9200" ;;
    "mt6989") echo "mtd9300" ;;
    "mt6991") echo "mtd9400" ;;
    *) echo "unsupported" ;;
    esac
}