    MODULE_PATH="$(dirname $(readlink -f "$0"))"
MODULE_PATH="${MODULE_PATH%\/script}"
          su -c mkdir /data/adb/modules/Xiao-Vulkan
       su -c unzip "$MODULE_PATH"/Enable_Vulkan_RenderEngine/Xiao-Vulkan.zip -d /data/adb/modules/Enable_Vulkan_RenderEngine/Xiao-Vulkan/