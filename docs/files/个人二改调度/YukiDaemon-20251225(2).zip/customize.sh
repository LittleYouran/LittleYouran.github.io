#!/system/bin/sh
#
# ########################################################################################
#   YukiDaemon 模块安装脚本
#   作者: 小疣然
# ########################################################################################

# --- 模块路径和工具 ---
# $MODPATH 是 Magisk 传入的模块安装路径
CONFIG_DIR="$MODPATH/config"
# 模块已自带默认配置文件于此路径
FINAL_CONFIG_PATH="$CONFIG_DIR/config.yaml"
# 临时下载位置
TEMP_DOWNLOAD_FILE="/data/local/tmp/yuki_config_download.yaml"
# --- 新增：APK 路径定义 ---
APK_FILE="$MODPATH/apk/Yuki Controller.apk"  # 假设 APK 在模块的 apk 文件夹下
APK_INSTALL_MSG=""
APK_INSTALL_SUCCESS_MSG=""
APK_INSTALL_FAIL_MSG=""
APK_NOT_FOUND_MSG=""

# --- 远程配置 URL ---
GITHUB_CONFIG_BASE_URL="https://raw.githubusercontent.com/imacte/YukiCtrl/main/configs"
GITEE_CONFIG_BASE_URL="https://gitee.com/imacte_ui/YUKICTRL/raw/main/configs"

# --- 自动检测 BusyBox ---
if [ -x "/data/adb/magisk/busybox" ]; then
  BUSYBOX="/data/adb/magisk/busybox"
elif [ -x "/data/adb/ksu/bin/busybox" ]; then
  BUSYBOX="/data/adb/ksu/bin/busybox"
else [ -x "/data/adb/ap/bin/busybox" ];
  BUSYBOX="/data/adb/ap/bin/busybox"
fi

# 确保临时文件在脚本退出时被删除
trap "$BUSYBOX rm -f $TEMP_DOWNLOAD_FILE" EXIT

# --- 语言定义 (Language Definitions) ---
# 1. 优先尝试获取用户设置的语言
CURRENT_LOCALE=$(/system/bin/getprop persist.sys.locale)

# 2. 如果为空，回退到 ROM 默认语言
if [ -z "$CURRENT_LOCALE" ]; then
    CURRENT_LOCALE=$(/system/bin/getprop ro.product.locale)
fi

# 默认使用英文
LANG_CODE="en"
MSG_GET_DEVICE_ID="-> 1. Getting device identifiers..."
MSG_FOUND_PLATFORM="   - Found ro.board.platform:"
MSG_FOUND_SOC_MODEL="   - Found SoC Model:"
MSG_EXTRACTED_SHORT_SOC="   - Extracted Short SoC:"
MSG_EXTRACTED_FULL_SOC="   - Extracted Full SoC:"
MSG_FINAL_IDENTIFIERS="   - Final identifier list:"
MSG_RESOLVE_SUCCESS="-> 2. Successfully resolved device to target config:"
MSG_RESOLVE_FAIL="-> ❌ Could not resolve any known target config for this device."
MSG_CHECK_BUILTIN="-> 3. Checking built-in configs..."
MSG_BUILTIN_FOUND="   - Built-in config found:"
MSG_BUILTIN_NOT_FOUND="   - Built-in config not found:"
MSG_BUILTIN_SUCCESS="   - ✔ [Built-in] Config loaded and validated successfully!"
MSG_BUILTIN_FAIL="   - ❌ [Built-in] Config validation failed."
MSG_CHECK_EXTERNAL="-> 4. Checking external config directory..."
MSG_EXTERNAL_EXISTS="   - External config directory exists:"
MSG_EXTERNAL_NOT_EXISTS="   - External config directory does not exist:"
MSG_TRY_EXTERNAL="   - Trying to load from [External]:"
MSG_EXTERNAL_FOUND="   - External config file found:"
MSG_EXTERNAL_NOT_FOUND="   - External config file not found:"
MSG_EXTERNAL_SUCCESS="   - ✔ [External] Config loaded and validated successfully!"
MSG_EXTERNAL_FAIL="   - ❌ [External] Config validation failed."
MSG_PREPARE_DOWNLOAD="-> 5. Preparing to download:"
MSG_TRY_GITHUB="   - Trying to download from [GitHub]..."
MSG_GITHUB_SUCCESS="   - ✔ [GitHub] Config downloaded and validated successfully!"
MSG_GITHUB_FAIL="   - ❌ [GitHub] Download failed or content validation failed."
MSG_SEPARATOR="   - -------------------------------"
MSG_TRY_GITEE="   - Trying to download from [Gitee]..."
MSG_GITEE_SUCCESS="   - ✔ [Gitee] Config downloaded and validated successfully!"
MSG_GITEE_FAIL="   - ❌ [Gitee] Download failed or content validation failed."
MSG_BUILTIN_APPLY_SUCCESS="-> ✔ Successfully applied built-in SoC-specific config:"
MSG_EXTERNAL_APPLY_SUCCESS="-> ✔ Successfully applied external SoC-specific config:"
MSG_DOWNLOAD_APPLY_SUCCESS="-> ✔ Successfully applied SoC-specific config:"
MSG_CONFIG_APPLY_PATH="   - Specific config replaced at:"
MSG_ALL_SOURCES_FAIL="-> ❌ Failed to load or download specific config."
MSG_FALLBACK="-> Module will use the built-in default config.yaml."
MSG_CONFIG_READY="-> Configuration files are ready."
# --- 新增：APK 安装相关语言提示 ---
APK_INSTALL_MSG="-> 6. Installing Yuki Controller APK..."
APK_INSTALL_SUCCESS_MSG="   - ✔ Yuki Controller.apk installed successfully!"
APK_INSTALL_FAIL_MSG="   - ❌ Failed to install Yuki Controller APK (error code: %d)"
APK_NOT_FOUND_MSG="   - ❌ Yuki Controller APK not found at: $APK_FILE"

# 检查是否包含 zh
if echo "$CURRENT_LOCALE" | $BUSYBOX grep -qi "zh"; then
  LANG_CODE="zh"
  MSG_GET_DEVICE_ID="-> 1. 正在获取设备标识符..."
  MSG_FOUND_PLATFORM="   - 发现 ro.board.platform:"
  MSG_FOUND_SOC_MODEL="   - 发现 SoC Model:"
  MSG_EXTRACTED_SHORT_SOC="   - 提取到 Short SoC:"
  MSG_EXTRACTED_FULL_SOC="   - 提取到 Full SoC:"
  MSG_FINAL_IDENTIFIERS="   - 最终标识符列表:"
  MSG_RESOLVE_SUCCESS="-> 2. 成功将设备解析为目标配置:"
  MSG_RESOLVE_FAIL="-> ❌ 无法为该设备解析出任何已知的目标配置。"
  MSG_CHECK_BUILTIN="-> 3. 正在检查内置配置文件..."
  MSG_BUILTIN_FOUND="   - 找到内置配置文件:"
  MSG_BUILTIN_NOT_FOUND="   - 内置配置文件未找到:"
  MSG_BUILTIN_SUCCESS="   - ✔ [内置] 配置加载并校验成功！"
  MSG_BUILTIN_FAIL="   - ❌ [内置] 配置校验失败。"
  MSG_CHECK_EXTERNAL="-> 4. 正在检查外部配置目录..."
  MSG_EXTERNAL_EXISTS="   - 外部配置目录存在:"
  MSG_EXTERNAL_NOT_EXISTS="   - 外部配置目录不存在:"
  MSG_TRY_EXTERNAL="   - 正在尝试从 [外部] 加载:"
  MSG_EXTERNAL_FOUND="   - 找到外部配置文件:"
  MSG_EXTERNAL_NOT_FOUND="   - 外部配置文件未找到:"
  MSG_EXTERNAL_SUCCESS="   - ✔ [外部] 配置加载并校验成功！"
  MSG_EXTERNAL_FAIL="   - ❌ [外部] 配置校验失败。"
  MSG_PREPARE_DOWNLOAD="-> 5. 准备下载:"
  MSG_TRY_GITHUB="   - 正在尝试从 [GitHub] 下载..."
  MSG_GITHUB_SUCCESS="   - ✔ [GitHub] 配置下载并校验成功！"
  MSG_GITHUB_FAIL="   - ❌ [GitHub] 下载失败或内容校验失败。"
  MSG_SEPARATOR="   - -------------------------------"
  MSG_TRY_GITEE="   - 正在尝试从 [Gitee] 下载..."
  MSG_GITEE_SUCCESS="   - ✔ [Gitee] 配置下载并校验成功！"
  MSG_GITEE_FAIL="   - ❌ [Gitee] 下载失败或内容校验失败。"
  MSG_BUILTIN_APPLY_SUCCESS="-> ✔ 成功应用内置SoC专用配置:"
  MSG_EXTERNAL_APPLY_SUCCESS="-> ✔ 成功应用外部SoC专用配置:"
  MSG_DOWNLOAD_APPLY_SUCCESS="-> ✔ 成功应用SoC专用配置:"
  MSG_CONFIG_APPLY_PATH="   - 专用配置已替换:"
  MSG_ALL_SOURCES_FAIL="-> ❌ 专用配置加载或下载失败。"
  MSG_FALLBACK="-> 模块将使用已内置的默认 config.yaml。"
  MSG_CONFIG_READY="-> 配置文件准备完成。"
  # --- 新增：APK 安装相关中文提示 ---
  APK_INSTALL_MSG="-> 6. 正在安装 Yuki Controller APK..."
  APK_INSTALL_SUCCESS_MSG="   - ✔ Yuki Controller.apk 安装成功！记得给予root权限 不可用其他接管器接管 包括scene"
  APK_INSTALL_FAIL_MSG="   - ❌ Yuki Controller APK 安装失败（错误码：%d）"
  APK_NOT_FOUND_MSG="   - ❌ 未找到 Yuki Controller APK，路径：$APK_FILE"
fi
# --- 语言定义结束 ---


get_device_identifiers() {
  ui_print " "
  ui_print "$MSG_GET_DEVICE_ID"
  
  IDENTIFIERS=""
  
  # 1a. 获取 ro.board.platform
  BOARD_PLATFORM=$(/system/bin/getprop ro.board.platform | $BUSYBOX tr '[:upper:]' '[:lower:]' | $BUSYBOX tr -d '[:space:]')
  if [ -n "$BOARD_PLATFORM" ]; then
      ui_print " $MSG_FOUND_PLATFORM $BOARD_PLATFORM"
      IDENTIFIERS="$IDENTIFIERS $BOARD_PLATFORM"
  fi

  # 1b. 获取 SoC Model
  RAW_SOC_MODEL=$(/system/bin/getprop ro.product.soc.model | $BUSYBOX tr '[:upper:]' '[:lower:]')
  if [ -z "$RAW_SOC_MODEL" ]; then
      RAW_SOC_MODEL=$(/system/bin/getprop ro.soc.model | $BUSYBOX tr '[:upper:]' '[:lower:]')
  fi
  # ---------------------------------

  if [ -n "$RAW_SOC_MODEL" ]; then
    ui_print " $MSG_FOUND_SOC_MODEL $RAW_SOC_MODEL"
    
    # 1c. 提取 shortSocPattern (e.g., sm8650)
    SHORT_SOC_MODEL=$($BUSYBOX echo "$RAW_SOC_MODEL" | $BUSYBOX sed -n 's/.*\(\(sm\|mt\|sdm\|sd\)[0-9]\{3,\}\).*/\1/p')
    if [ -n "$SHORT_SOC_MODEL" ]; then
          ui_print " $MSG_EXTRACTED_SHORT_SOC $SHORT_SOC_MODEL"
          IDENTIFIERS="$IDENTIFIERS $SHORT_SOC_MODEL"
    fi
    
    # 1d. 提取 fullSocModelFilename (e.g., snapdragon_8_gen_3)
    FULL_SOC_MODEL_FILENAME=$($BUSYBOX echo "$RAW_SOC_MODEL" | $BUSYBOX tr ' /' '__')
    if [ -n "$FULL_SOC_MODEL_FILENAME" ]; then
        ui_print " $MSG_EXTRACTED_FULL_SOC $FULL_SOC_MODEL_FILENAME"
        IDENTIFIERS="$IDENTIFIERS $FULL_SOC_MODEL_FILENAME"
    fi
  fi

  # 1e. 过滤重复项 (distinct)
  DISTINCT_IDENTIFIERS=$($BUSYBOX echo "$IDENTIFIERS" | $BUSYBOX awk '{for(i=1;i<=NF;i++)if(!a[$i]++)printf "%s ",$i}')
  ui_print " $MSG_FINAL_IDENTIFIERS $DISTINCT_IDENTIFIERS"
  
  echo "$DISTINCT_IDENTIFIERS"
}

resolve_canonical_name() {
    local identifier_list="$1"
    local canonical_name=""
    
    for identifier in $identifier_list; do
        case "$identifier" in
            "mt6833") canonical_name="mt6833"; break ;;
            "mt6891") canonical_name="mt6891"; break ;;
            "mt6895") canonical_name="mt6895"; break ;;
            "mt6983") canonical_name="mt6983"; break ;;
            "mt6983z") canonical_name="mt6983z"; break ;;
            "mt6985") canonical_name="mt6985"; break ;;
            "mt6985z"|"rubens") canonical_name="mt6985z"; break ;;
            "mt6989"|"mt8796") canonical_name="mt6989"; break ;;
            "mt6991") canonical_name="mt6991"; break ;;
            "sm7475") canonical_name="sm7475"; break ;;
            "sm8150") canonical_name="sm8150"; break ;;
            "sm8250-ac"|"kona") canonical_name="sm8250-ac"; break ;;
            "sm8350") canonical_name="sm8350"; break ;;
            "sm8450") canonical_name="sm8450"; break ;;
            "sm8475") canonical_name="sm8475"; break ;;
            "sm8550"|"kalama") canonical_name="sm8550"; break ;;
            "sm8650"|"pineapple") canonical_name="sm8650"; break ;;
            "sm8750") canonical_name="sm8750"; break ;;
            "sm8750p") canonical_name="sm8750p"; break ;;
        esac
    done
    
    echo "$canonical_name"
}

validate_config_content() {
    local file_path="$1"
    local expected_name="$2"
    
    if [ ! -s "$file_path" ]; then
        return 1 # 文件不存在或为空
    fi
    
    # 使用简单的grep检查，避免awk脚本问题
    if $BUSYBOX grep -i "meta:" "$file_path" > /dev/null 2>&1 && \
       $BUSYBOX grep -i "name:" "$file_path" | $BUSYBOX grep -i "$expected_name" > /dev/null 2>&1; then
        return 0 # 校验成功
    else
        # 如果简单检查失败，尝试更精确的检查
        local meta_section=$($BUSYBOX sed -n '/meta:/,/^[a-zA-Z]/p' "$file_path" | $BUSYBOX head -10)
        if echo "$meta_section" | $BUSYBOX grep -i "name:" | $BUSYBOX grep -i "$expected_name" > /dev/null 2>&1; then
            return 0
        fi
        return 1 # 校验失败
    fi
}

load_builtin_config() {
    local target_name="$1"
    local builtin_config_path="$CONFIG_DIR/${target_name}.yaml"
    
    ui_print " "
    ui_print "$MSG_CHECK_BUILTIN"
    
    if [ -f "$builtin_config_path" ]; then
        ui_print " $MSG_BUILTIN_FOUND $builtin_config_path"
        
        # 清理临时文件
        $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
        
        # 复制到临时位置进行验证
        if $BUSYBOX cp "$builtin_config_path" "$TEMP_DOWNLOAD_FILE"; then
            if validate_config_content "$TEMP_DOWNLOAD_FILE" "$target_name"; then
                ui_print " $MSG_BUILTIN_SUCCESS"
                # 替换模块中的默认配置
                if $BUSYBOX mv -f "$TEMP_DOWNLOAD_FILE" "$FINAL_CONFIG_PATH"; then
                    return 0
                else
                    ui_print " $MSG_BUILTIN_FAIL"
                fi
            else
                ui_print " $MSG_BUILTIN_FAIL"
            fi
        fi
        # 清理临时文件
        $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
    else
        ui_print " $MSG_BUILTIN_NOT_FOUND $builtin_config_path"
        # 列出内置配置文件用于调试
        ui_print "   - Available built-in configs:"
        $BUSYBOX ls "$CONFIG_DIR"/*.yaml | $BUSYBOX grep -v "config.yaml" | while read file; do
            ui_print "     $($BUSYBOX basename "$file")"
        done
    fi
    
    return 1
}

load_external_config() {
    local target_name="$1"
    local external_config_path="/config/${target_name}.yaml"
    
    ui_print " "
    ui_print "$MSG_CHECK_EXTERNAL"
    
    if [ -d "/config" ]; then
        ui_print " $MSG_EXTERNAL_EXISTS /config"
        ui_print " $MSG_TRY_EXTERNAL $external_config_path"
        
        if [ -f "$external_config_path" ]; then
            ui_print " $MSG_EXTERNAL_FOUND $external_config_path"
            
            # 清理临时文件
            $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
            
            # 复制到临时位置进行验证
            if $BUSYBOX cp "$external_config_path" "$TEMP_DOWNLOAD_FILE"; then
                if validate_config_content "$TEMP_DOWNLOAD_FILE" "$target_name"; then
                    ui_print " $MSG_EXTERNAL_SUCCESS"
                    # 替换模块中的默认配置
                    if $BUSYBOX mv -f "$TEMP_DOWNLOAD_FILE" "$FINAL_CONFIG_PATH"; then
                        return 0
                    else
                        ui_print " $MSG_EXTERNAL_FAIL"
                    fi
                else
                    ui_print " $MSG_EXTERNAL_FAIL"
                fi
            fi
            # 清理临时文件
            $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
        else
            ui_print " $MSG_EXTERNAL_NOT_FOUND $external_config_path"
        fi
    else
        ui_print " $MSG_EXTERNAL_NOT_EXISTS /config"
    fi
    
    return 1
}

download_config() {
    local target_name="$1"
    local remote_filename="$target_name.yaml"
    
    ui_print " "
    ui_print "$MSG_PREPARE_DOWNLOAD $remote_filename"
    
    # --- 尝试源 1: GitHub ---
    ui_print " $MSG_TRY_GITHUB"
    local config_url_github="$GITHUB_CONFIG_BASE_URL/$remote_filename"
    $BUSYBOX wget -T 10 -qO "$TEMP_DOWNLOAD_FILE" "$config_url_github"
    
    if validate_config_content "$TEMP_DOWNLOAD_FILE" "$target_name"; then
        ui_print " $MSG_GITHUB_SUCCESS"
        # 替换模块中的默认配置
        $BUSYBOX mv -f "$TEMP_DOWNLOAD_FILE" "$FINAL_CONFIG_PATH"
        return 0
    else
        ui_print " $MSG_GITHUB_FAIL"
        $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
    fi

    # --- 尝试源 2: Gitee ---
    ui_print " $MSG_SEPARATOR"
    ui_print " $MSG_TRY_GITEE"
    local config_url_gitee="$GITEE_CONFIG_BASE_URL/$remote_filename"
    $BUSYBOX wget -T 10 -qO "$TEMP_DOWNLOAD_FILE" "$config_url_gitee"
    
    if validate_config_content "$TEMP_DOWNLOAD_FILE" "$target_name"; then
        ui_print " $MSG_GITEE_SUCCESS"
        # 替换模块中的默认配置
        $BUSYBOX mv -f "$TEMP_DOWNLOAD_FILE" "$FINAL_CONFIG_PATH"
        return 0
    else
        ui_print " $MSG_GITEE_FAIL"
        $BUSYBOX rm -f "$TEMP_DOWNLOAD_FILE"
    fi
    
    return 1
}

# --- APK 安装函数 ---
install_apk() {
    ui_print " "
    ui_print "$APK_INSTALL_MSG"
    
    # 检查 APK 文件是否存在且非空
    if [ ! -f "$APK_FILE" ] || [ ! -s "$APK_FILE" ]; then
        ui_print " $APK_NOT_FOUND_MSG"
        # 插入圣诞祝福内容
        ui_print " "
        ui_print "小疣然: Merry Christmas （圣诞快乐）"
        ui_print "                    🌟"
        ui_print "                   🎄🎄"
        ui_print "                  🎄🎄🎄"
        ui_print "                 🎄🎄🎄🎄"
        ui_print "                🎄🎄🎄🎄🎄"
        ui_print "               🎄🎄🎄🎄🎄🎄"
        ui_print "                 [🎁][🎁]"
        ui_print "                   [🦌]"
        ui_print "    如果你见到了圣诞老人跟他说别送他都没有的"
        ui_print " "
        return 1
    fi
    
    # 执行 APK 安装（使用系统 pm 命令，兼容 root 环境）
    /system/bin/pm install -r "$APK_FILE"
    INSTALL_EXIT_CODE=$?
    
    # 根据退出码判断安装结果
    if [ $INSTALL_EXIT_CODE -eq 0 ]; then
        ui_print " $APK_INSTALL_SUCCESS_MSG"
        return 0
    else
        # 输出错误码（常见错误码：1=安装失败，-1=权限不足，22=签名不匹配等）
        ui_print " $(printf "$APK_INSTALL_FAIL_MSG" $INSTALL_EXIT_CODE)"
        # 插入圣诞祝福内容
        ui_print " "
        ui_print "小疣然: Merry Christmas （圣诞快乐）"
        ui_print "                    🌟"
        ui_print "                   🎄🎄"
        ui_print "                  🎄🎄🎄"
        ui_print "                 🎄🎄🎄🎄"
        ui_print "                🎄🎄🎄🎄🎄"
        ui_print "               🎄🎄🎄🎄🎄🎄"
        ui_print "                 [🎁][🎁]"
        ui_print "                   [🦌]"
        ui_print "    如果你见到了圣诞老人跟他说别送他都没有的"
        ui_print " "
        return 1
    fi
}

# 步骤 1 & 2: 获取标识符并解析
ALL_IDENTIFIERS=$(get_device_identifiers)
TARGET_CONFIG_NAME=$(resolve_canonical_name "$ALL_IDENTIFIERS")

if [ -z "$TARGET_CONFIG_NAME" ]; then
    ui_print " "
    ui_print "$MSG_RESOLVE_FAIL"
    CONFIG_LOADED=false
else
    ui_print " "
    ui_print "$MSG_RESOLVE_SUCCESS $TARGET_CONFIG_NAME"
    
    # 步骤 3: 优先尝试加载内置配置（模块自带的）
    if load_builtin_config "$TARGET_CONFIG_NAME"; then
        CONFIG_LOADED=true
        LOAD_SOURCE="builtin"
    else
        # 步骤 4: 内置配置失败，尝试外部配置
        if load_external_config "$TARGET_CONFIG_NAME"; then
            CONFIG_LOADED=true
            LOAD_SOURCE="external"
        else
            # 步骤 5: 外部配置失败，尝试网络下载
            if download_config "$TARGET_CONFIG_NAME"; then
                CONFIG_LOADED=true
                LOAD_SOURCE="download"
            else
                CONFIG_LOADED=false
            fi
        fi
    fi
fi

# 步骤 6: 处理配置加载结果
if [ "$CONFIG_LOADED" = true ]; then
    ui_print " "
    case "$LOAD_SOURCE" in
        "builtin")
            ui_print "$MSG_BUILTIN_APPLY_SUCCESS $TARGET_CONFIG_NAME"
            ;;
        "external")
            ui_print "$MSG_EXTERNAL_APPLY_SUCCESS $TARGET_CONFIG_NAME"
            ;;
        "download")
            ui_print "$MSG_DOWNLOAD_APPLY_SUCCESS $TARGET_CONFIG_NAME"
            ;;
    esac
    ui_print " $MSG_CONFIG_APPLY_PATH $FINAL_CONFIG_PATH"
else
    ui_print " "
    ui_print "$MSG_ALL_SOURCES_FAIL"
    ui_print "$MSG_FALLBACK"
    # (什么也不做，保留 $FINAL_CONFIG_PATH 的原文件)
fi

# --- 执行 APK 安装（除终止安装外，所有场景都执行）---
install_apk

ui_print " "
ui_print "$MSG_CONFIG_READY"
